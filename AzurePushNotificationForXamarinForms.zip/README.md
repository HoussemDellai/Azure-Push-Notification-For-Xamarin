# Azure-Push-Notification-For-Xamarin

This plugin makes it easy to register to Microsoft Azure Push Notifications from a Xamarin project. This supports using Tags.

The supported projects are:
- Xamarin.Android
- Windows Phone 8.1 RT
- Windows Phone Silverlight
- Windows Store 8

The resulted Nuget Package is published on Nuget website</br>
https://www.nuget.org/packages/Xam.Plugin.AzurePushNotification/</br>
And could be installed inside your project via Nuget Package Manager or via the Package Manager Console:</br>
PM> Install-Package Xam.Plugin.AzurePushNotification</br>
