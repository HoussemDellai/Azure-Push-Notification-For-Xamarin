using AzurePushNotificationForXamarinForms.Plugin.Abstractions;
using System;


namespace AzurePushNotificationForXamarinForms.Plugin
{
  /// <summary>
  /// Implementation for AzurePushNotificationForXamarinForms
  /// </summary>
  public class AzurePushNotificationForXamarinFormsImplementation : IAzurePushNotificationForXamarinForms
  {
      public void RegisterForAzurePushNotification(object obj)
      {
            
      }
  }
}