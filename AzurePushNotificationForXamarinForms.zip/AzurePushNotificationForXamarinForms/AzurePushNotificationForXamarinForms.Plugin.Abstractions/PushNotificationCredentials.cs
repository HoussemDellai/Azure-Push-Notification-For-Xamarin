

namespace AzurePushNotificationForXamarinForms.Plugin.Abstractions
{
    /// <summary>
    /// Contains credentials for accessing Microsoft Azure Push Notifications 
    /// and Google Cloud Messaging.
    /// </summary>
    public static class PushNotificationCredentials
    {

        /// <summary>
        /// Google API Project Number.
        /// </summary>
        public static string GoogleApiSenderId = "536442481057"; // 

        public static string AzureNotificationHubName = "haltaalamnotificationhub";

        public static string AzureListenConnectionString = "Endpoint=sb://haltaalam.servicebus.windows.net/;SharedAccessKeyName=DefaultListenSharedAccessSignature;SharedAccessKey=iPouaer4JOoK2w8EHALyCWCmRwnLYP/MapP+YkYeZF8=";
    }
}