﻿using System;

namespace AzurePushNotificationForXamarinForms.Plugin.Abstractions
{
  /// <summary>
  /// Interface for AzurePushNotificationForXamarinForms
  /// </summary>
  public interface IAzurePushNotificationForXamarinForms
  {

      void RegisterForAzurePushNotification(object obj);
  }
}
